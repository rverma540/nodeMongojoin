module.exports = {
    Product: require("./Product"),
    Review: require("./Review")
  };